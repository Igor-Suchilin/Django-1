from django.contrib import admin
from .models import Drinky, Category

admin.site.register(Drinky)
admin.site.register(Category)